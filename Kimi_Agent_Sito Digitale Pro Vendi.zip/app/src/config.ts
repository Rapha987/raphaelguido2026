// =============================================================================
// Site Configuration
// Edit ONLY this file to customize all content across the site.
// All animations, layouts, and styles are controlled by the components.
// =============================================================================

// -- Site-wide settings -------------------------------------------------------
export interface SiteConfig {
  title: string;
  description: string;
  language: string;
}

export const siteConfig: SiteConfig = {
  title: "Digital Solutions Pro - Consulenza Digitale",
  description: "Sei bloccato con qualcosa di digitale? Ti aiuto a risolvere qualsiasi problema digitale. Sviluppo web, marketing, consulenza tech.",
  language: "it",
};

// -- Hero Section -------------------------------------------------------------
export interface HeroNavItem {
  label: string;
  sectionId: string;
  icon: "disc" | "play" | "calendar" | "music";
}

export interface HeroConfig {
  backgroundImage: string;
  brandName: string;
  decodeText: string;
  decodeChars: string;
  subtitle: string;
  ctaPrimary: string;
  ctaPrimaryTarget: string;
  ctaSecondary: string;
  ctaSecondaryTarget: string;
  cornerLabel: string;
  cornerDetail: string;
  navItems: HeroNavItem[];
}

export const heroConfig: HeroConfig = {
  backgroundImage: "/hero-bg.jpg",
  brandName: "DIGITAL PRO",
  decodeText: "SOLUZIONI DIGITALI",
  decodeChars: "01#@$%&*",
  subtitle: "Sei bloccato con qualcosa di digitale e non sai da dove partire? Scrivimi. Risolvo qualsiasi problema tech.",
  ctaPrimary: "Inizia Ora",
  ctaPrimaryTarget: "contact",
  ctaSecondary: "Scopri di Più",
  ctaSecondaryTarget: "services",
  cornerLabel: "DISPONIBILE",
  cornerDetail: "Consulenza Immediata",
  navItems: [
    { label: "Servizi", sectionId: "services", icon: "disc" },
    { label: "Portfolio", sectionId: "gallery", icon: "play" },
    { label: "Progetti", sectionId: "tour", icon: "calendar" },
    { label: "Contatti", sectionId: "contact", icon: "music" },
  ],
};

// -- Album Cube Section -------------------------------------------------------
export interface Album {
  id: number;
  title: string;
  subtitle: string;
  image: string;
}

export interface AlbumCubeConfig {
  albums: Album[];
  cubeTextures: string[];
  scrollHint: string;
}

export const albumCubeConfig: AlbumCubeConfig = {
  albums: [
    { id: 1, title: "WEB DEV", subtitle: "Sviluppo Web", image: "/cube-1.jpg" },
    { id: 2, title: "MARKETING", subtitle: "Digital Marketing", image: "/cube-2.jpg" },
    { id: 3, title: "CONSULENZA", subtitle: "Tech Support", image: "/cube-3.jpg" },
    { id: 4, title: "SICUREZZA", subtitle: "Cybersecurity", image: "/cube-4.jpg" },
  ],
  cubeTextures: [
    "/cube-1.jpg",
    "/cube-2.jpg",
    "/cube-3.jpg",
    "/cube-4.jpg",
    "/cube-5.jpg",
    "/cube-6.jpg",
  ],
  scrollHint: "Scorri per esplorare i servizi",
};

// -- Parallax Gallery Section -------------------------------------------------
export interface ParallaxImage {
  id: number;
  src: string;
  alt: string;
}

export interface GalleryImage {
  id: number;
  src: string;
  title: string;
  date: string;
}

export interface ParallaxGalleryConfig {
  sectionLabel: string;
  sectionTitle: string;
  galleryLabel: string;
  galleryTitle: string;
  marqueeTexts: string[];
  endCtaText: string;
  parallaxImagesTop: ParallaxImage[];
  parallaxImagesBottom: ParallaxImage[];
  galleryImages: GalleryImage[];
}

export const parallaxGalleryConfig: ParallaxGalleryConfig = {
  sectionLabel: "COSA FACCIO",
  sectionTitle: "SERVIZI DIGITALI COMPLETI",
  galleryLabel: "PORTFOLIO",
  galleryTitle: "I MIEI PROGETTI",
  marqueeTexts: [
    "SVILUPPO WEB",
    "MARKETING DIGITALE",
    "CONSULENZA TECH",
    "SICUREZZA INFORMATICA",
    "OTTIMIZZAZIONE SEO",
    "E-COMMERCE",
    "SOCIAL MEDIA",
    "AUTOMATION",
  ],
  endCtaText: "Hai un progetto in mente? Parliamone!",
  parallaxImagesTop: [
    { id: 1, src: "/parallax-1.jpg", alt: "Mobile Development" },
    { id: 2, src: "/parallax-2.jpg", alt: "SEO Optimization" },
    { id: 3, src: "/parallax-3.jpg", alt: "Content Creation" },
    { id: 4, src: "/parallax-1.jpg", alt: "App Development" },
    { id: 5, src: "/parallax-2.jpg", alt: "Analytics" },
    { id: 6, src: "/parallax-3.jpg", alt: "Video Editing" },
  ],
  parallaxImagesBottom: [
    { id: 1, src: "/parallax-4.jpg", alt: "Database Integration" },
    { id: 2, src: "/parallax-5.jpg", alt: "Digital Consulting" },
    { id: 3, src: "/parallax-6.jpg", alt: "Automation" },
    { id: 4, src: "/parallax-4.jpg", alt: "API Development" },
    { id: 5, src: "/parallax-5.jpg", alt: "Business Strategy" },
    { id: 6, src: "/parallax-6.jpg", alt: "Workflow Optimization" },
  ],
  galleryImages: [
    { id: 1, src: "/gallery-1.jpg", title: "Sviluppo Web", date: "2024" },
    { id: 2, src: "/gallery-2.jpg", title: "Analytics Dashboard", date: "2024" },
    { id: 3, src: "/gallery-3.jpg", title: "UI/UX Design", date: "2024" },
    { id: 4, src: "/gallery-4.jpg", title: "E-Commerce", date: "2024" },
    { id: 5, src: "/gallery-5.jpg", title: "Social Media", date: "2024" },
    { id: 6, src: "/gallery-6.jpg", title: "Cloud Solutions", date: "2024" },
  ],
};

// -- Tour Schedule Section ----------------------------------------------------
export interface TourDate {
  id: number;
  date: string;
  time: string;
  city: string;
  venue: string;
  status: "on-sale" | "sold-out" | "coming-soon";
  image: string;
}

export interface TourStatusLabels {
  onSale: string;
  soldOut: string;
  comingSoon: string;
  default: string;
}

export interface TourScheduleConfig {
  sectionLabel: string;
  sectionTitle: string;
  vinylImage: string;
  buyButtonText: string;
  detailsButtonText: string;
  bottomNote: string;
  bottomCtaText: string;
  statusLabels: TourStatusLabels;
  tourDates: TourDate[];
}

export const tourScheduleConfig: TourScheduleConfig = {
  sectionLabel: "PROGETTI RECENTI",
  sectionTitle: "ULTIMI LAVORI",
  vinylImage: "/vinyl-disc.png",
  buyButtonText: "Vedi Progetto",
  detailsButtonText: "Dettagli",
  bottomNote: "Hai un progetto in mente?",
  bottomCtaText: "Contattami Ora",
  statusLabels: {
    onSale: "COMPLETATO",
    soldOut: "IN CORSO",
    comingSoon: "IN ARRIVO",
    default: "INFO",
  },
  tourDates: [
    {
      id: 1,
      date: "2024.12.15",
      time: "14:00",
      city: "E-Commerce",
      venue: "Shop Online Completo",
      status: "on-sale",
      image: "/gallery-4.jpg",
    },
    {
      id: 2,
      date: "2024.11.20",
      time: "10:30",
      city: "Web App",
      venue: "Dashboard Analytics",
      status: "on-sale",
      image: "/gallery-2.jpg",
    },
    {
      id: 3,
      date: "2025.01.10",
      time: "09:00",
      city: "Mobile App",
      venue: "App iOS/Android",
      status: "coming-soon",
      image: "/parallax-1.jpg",
    },
    {
      id: 4,
      date: "2024.10.05",
      time: "16:00",
      city: "Marketing",
      venue: "Campagna Social Media",
      status: "on-sale",
      image: "/gallery-5.jpg",
    },
  ],
};

// -- Footer Section -----------------------------------------------------------
export interface FooterImage {
  id: number;
  src: string;
}

export interface SocialLink {
  icon: "instagram" | "twitter" | "youtube" | "music";
  label: string;
  href: string;
}

export interface FooterConfig {
  portraitImage: string;
  portraitAlt: string;
  heroTitle: string;
  heroSubtitle: string;
  artistLabel: string;
  artistName: string;
  artistSubtitle: string;
  brandName: string;
  brandDescription: string;
  quickLinksTitle: string;
  quickLinks: string[];
  contactTitle: string;
  emailLabel: string;
  email: string;
  phoneLabel: string;
  phone: string;
  addressLabel: string;
  address: string;
  newsletterTitle: string;
  newsletterDescription: string;
  newsletterButtonText: string;
  subscribeAlertMessage: string;
  copyrightText: string;
  bottomLinks: string[];
  socialLinks: SocialLink[];
  galleryImages: FooterImage[];
}

export const footerConfig: FooterConfig = {
  portraitImage: "/portrait.jpg",
  portraitAlt: "Digital Solutions Pro - Consulente Digitale",
  heroTitle: "PRONTO A INIZIARE?",
  heroSubtitle: "Trasformiamo le tue idee in realtà digitale",
  artistLabel: "IL TUO CONSULENTE",
  artistName: "Digital Pro",
  artistSubtitle: "Esperto in Soluzioni Digitali",
  brandName: "DIGITAL SOLUTIONS PRO",
  brandDescription: "Offro consulenza digitale completa per aiutarti a superare qualsiasi ostacolo tecnologico. Dal web development al marketing digitale, sono qui per te.",
  quickLinksTitle: "Link Rapidi",
  quickLinks: ["Servizi", "Portfolio", "Progetti", "Contatti"],
  contactTitle: "Contatti",
  emailLabel: "Email",
  email: "info@digitalsolutionspro.it",
  phoneLabel: "Telefono",
  phone: "+39 333 123 4567",
  addressLabel: "Location",
  address: "Italia - Consulenza Remota",
  newsletterTitle: "Resta Aggiornato",
  newsletterDescription: "Iscriviti per ricevere consigli digitali e novità tech",
  newsletterButtonText: "Iscriviti",
  subscribeAlertMessage: "Grazie per l'iscrizione! Riceverai presto i nostri aggiornamenti.",
  copyrightText: "© 2024 Digital Solutions Pro. Tutti i diritti riservati.",
  bottomLinks: ["Privacy Policy", "Termini di Servizio", "Cookie Policy"],
  socialLinks: [
    { icon: "instagram", label: "Instagram", href: "https://instagram.com" },
    { icon: "twitter", label: "Twitter", href: "https://twitter.com" },
    { icon: "youtube", label: "YouTube", href: "https://youtube.com" },
    { icon: "music", label: "LinkedIn", href: "https://linkedin.com" },
  ],
  galleryImages: [
    { id: 1, src: "/gallery-1.jpg" },
    { id: 2, src: "/gallery-2.jpg" },
    { id: 3, src: "/gallery-3.jpg" },
    { id: 4, src: "/gallery-4.jpg" },
  ],
};
